import psycopg2
import pandas as pd
from sqlalchemy import create_engine
import openpyxl
import datetime
import json


config = json.load(open('config.json'))


def fetch_sitedb():
    input_path = './input'
    try:
        conn = psycopg2.connect(database="inventorydb_bha", user="guest_user", password="Nokia@123",
                                host="10.133.132.180",
                                port="5432")
        cur = conn.cursor()

        cur.execute(r'select * from dbo."Table2G"')
        rows = cur.fetchall()

        sitedb_dict = []

        for row in rows:
            temp1 = row[2]
            temp2 = row[3]
            temp3 = {'project_id': row[1]}
            temp1.update(temp2)
            temp1.update(temp3)
            temp = {}
            for k, v in temp1.items():
                if type(v) is type(' ') and v.isnumeric():
                    v = eval(v)
                temp[k] = v
            sitedb_dict.append(temp)
    except Exception as e:
        print(e)
    finally:
        cur.close()
        conn.close()

    sitedb = pd.DataFrame(sitedb_dict)
    project_details = pd.read_sql_table('projectDetails', create_engine('postgresql://guest_user:Nokia@123@10.133.132.180:5432/inventorydb_bha', connect_args = {'options':'-csearch_path={}'.format('dbo')}))

    sitedb_details = pd.merge(sitedb, project_details, how='left', left_on='project_id', right_on='id')
    sitedb_details = sitedb_details.drop(['project_id', 'id'], axis=1)

    country = 'congo'

    sitedb_details = sitedb_details[sitedb_details['country'].str.lower() == country]

    sitedb_details.to_csv(input_path+'/sitedb_2g.csv', index=False)


def calculate_bbh(opco):
    df = pd.read_csv(config[opco]['raw'], low_memory=False, delimiter=';')

    cell = df['Segment Name'].tolist()
    bsc = df['BSC name'].tolist()
    condition = [(cell[i].lower(), bsc[i].lower()) for i in range(len(cell))]

    sitedb = pd.read_csv(config[opco]['sitedb'], low_memory=False)
    sitedb['cell'] = sitedb['CI-Name'].str.lower()
    sitedb['bsc'] = sitedb['BSC'].str.lower()
    sitedb_b = sitedb[sitedb[['cell', 'bsc']].apply(tuple, axis=1).isin(condition)]

    hourly = pd.merge(sitedb_b, df, how='inner', left_on=['CI-Name', 'BSC'], right_on=['Segment Name', 'BSC name'])
    hourly = hourly.sort_values(['PERIOD_START_TIME'])
    all_bbh = hourly.sort_values(by=['total_traffic_erlangs', 'PERIOD_START_TIME'], ascending=[False, True]).drop_duplicates('CI-Name').sort_index()

    sitedb_r = sitedb[~sitedb[['cell', 'bsc']].apply(tuple, axis=1).isin(condition)]

    all_bbh = pd.concat([all_bbh, sitedb_r])

    return all_bbh


def update_report():
    for opco in config.keys():
        report = pd.DataFrame()
        bbh = calculate_bbh(opco)

        report['CELL'] = bbh['OSS_Cell_ID-Name']
        report['Site id'] = bbh['SITE_ID']
        report['Region'] = bbh['REGION']
        report['Site Name'] = bbh['Site_Name']
        report['Showcase'] = bbh['SitePreference']
        report['MACRO/IBS'] = bbh['MACRO_IBS']
        report['BSC'] = bbh['BSC']
        report['TRX'] = bbh['Net_TRXs_Available']
        report['TOWN'] = bbh['HQ_TOWN']
        report['STATE'] = bbh['STATE']
        report['Site Name'] = bbh['Site_Name']
        report['Total  TRX'] = bbh['Net_TRXs_Available']
        report['DATA TS'] = bbh['FPDCH']
        report['SDCCH TS'] = bbh['NOOFSDCCH']
        report['MSC'] = bbh['MSC']
        report['Current Voice TS'] = bbh['Total_TS_Available']
        report['Capacity FR'] = bbh['Equipped_Erlang_Capacity_forVoice']
        report['cell_id'] = bbh['OSS_Cell_ID-Name']

        report['Latest Traffic'] = bbh['total_traffic_erlangs']
        report['Latest TCH Congestion'] = (bbh['TCH_Blocking_Nom'] / bbh['TCH_Blocking_Denom']) * 100
        report.loc[report['Latest TCH Congestion'] < 0, 'Latest TCH Congestion'] = 0
        report['Latest SDCCH Congestion'] = (bbh['sdcch_blocking_nom'] / bbh['sdcch_blocking_denom']) * 100
        report.loc[report['Latest SDCCH Congestion'] < 0, 'Latest SDCCH Congestion'] = 0
        report['cell_id'] = bbh['Cell id']

        report['Date(utilization)'] = report['Latest Traffic']/report['Capacity FR']
        report['ZONE'] = ''

        report = report.drop(columns=['cell_id'])

        wb = openpyxl.load_workbook(config[opco]['template'])
        bbh['PERIOD_START_TIME'] = pd.to_datetime(bbh['PERIOD_START_TIME']).dt.strftime('%d-%b-%Y %H:%M')
        date = (bbh['PERIOD_START_TIME'].tolist()[0]).split()[0]

        for ws in wb.worksheets:
            l1 = []
            sheet = str(ws).split('"')[1]
            flag = False
            if sheet == 'Utilization Tracker':
                flag = True
                df = report[['CELL', 'Site id', 'Region', 'Site Name', 'Showcase', 'MACRO/IBS',
                   'BSC', 'TRX', 'TOWN', 'STATE', 'Total  TRX', 'DATA TS', 'SDCCH TS',
                   'MSC', 'Current Voice TS', 'Capacity FR', 'Latest Traffic',
                   'Latest TCH Congestion', 'Latest SDCCH Congestion',
                   'Date(utilization)']]
                c = len(df.columns)
                data = 'Date(utilization)'

            elif sheet == 'Daily BH traffic':
                flag = True
                data = 'Latest Traffic'
                df = report[['CELL', 'Site id', 'Region', 'ZONE', 'Showcase', 'MACRO/IBS', 'BSC', 'Latest Traffic']]
                c = len(df.columns)

            elif sheet == 'TCH_CONGESTION':
                flag = True
                data = 'Latest TCH Congestion'
                df = report[
                    ['CELL', 'Site id', 'Region', 'ZONE', 'Showcase', 'MACRO/IBS', 'BSC', 'Latest TCH Congestion']]
                c = len(df.columns)

            elif sheet == 'SDCCH_CONGESTION':
                flag = True
                data = 'Latest SDCCH Congestion'
                df = report[
                    ['CELL', 'Site id', 'Region', 'ZONE', 'Showcase', 'MACRO/IBS', 'BSC', 'Latest SDCCH Congestion']]
                c = len(df.columns)

            elif sheet == 'TRX TRACKER':
                flag = True
                data = 'Total  TRX'
                df = report[
                    ['CELL', 'Site id', 'Region', 'ZONE', 'Showcase', 'MACRO/IBS', 'BSC', 'Total  TRX']]
                c = len(df.columns)

            if flag:
                rowIndex = 3
                colIndex = 1
                while colIndex > 0:
                    if ws.cell(row=rowIndex, column=colIndex).value is None:
                        break
                    colIndex += 1

                for i in range(rowIndex+1, ws.max_row+1):
                    cell = ws.cell(i, 1).value
                    if cell in list(df['CELL']):
                        l1.append(cell)
                        temp = df[df['CELL'] == cell]
                        for j in range(2, c):
                            ws.cell(row=i, column=j).value = temp[ws.cell(row=rowIndex, column=j).value].values[0]
                        ws.cell(row=i, column=colIndex).value = temp[data].values[0]
                ws.cell(row=rowIndex, column=colIndex).value = date

        date = datetime.datetime.strptime(date, '%d-%b-%Y').strftime('%Y%m%d')
        wb.save(config[opco]['output'] + 'Utilization_Tracker_' + opco + '_' + date + '.xlsx')
        wb.close()


update_report()


