import psycopg2
import pandas as pd
from sqlalchemy import create_engine
import openpyxl
import datetime
import json
import numpy as np


config = json.load(open('config.json'))


def fetch_sitedb():
    input_path = './input'
    try:
        conn = psycopg2.connect(database="inventorydb_bha", user="guest_user", password="Nokia@123",
                                host="10.133.132.180",
                                port="5432")
        cur = conn.cursor()

        cur.execute(r'select * from dbo."Table2G"')
        rows = cur.fetchall()

        sitedb_dict = []

        for row in rows:
            temp1 = row[2]
            temp2 = row[3]
            temp3 = {'project_id': row[1]}
            temp1.update(temp2)
            temp1.update(temp3)
            temp = {}
            for k, v in temp1.items():
                if type(v) is type(' ') and v.isnumeric():
                    v = eval(v)
                temp[k] = v
            sitedb_dict.append(temp)
    except Exception as e:
        print(e)
    finally:
        cur.close()
        conn.close()

    sitedb = pd.DataFrame(sitedb_dict)
    project_details = pd.read_sql_table('projectDetails', create_engine(
        'postgresql://guest_user:Nokia@123@10.133.132.180:5432/inventorydb_bha',
        connect_args={'options': '-csearch_path={}'.format('dbo')}))

    sitedb_details = pd.merge(sitedb, project_details, how='left',
                              left_on='project_id', right_on='id')
    sitedb_details = sitedb_details.drop(['project_id', 'id'], axis=1)

    country = 'congo'

    sitedb_details = sitedb_details[sitedb_details['country'].str.lower() == country]

    sitedb_details.to_csv(input_path + '/sitedb_2g.csv', index=False)


def fetch_mapping(vendor, opco):
    vendors_list = pd.read_excel(config[opco]['mapping'])
    cols = []
    for col in vendors_list:
        if 'file name' in str(col).lower() or 'file_name' in str(col).lower():
            continue
        cols.append(col)

    vendors_list = vendors_list[cols]

    index = -1
    for i, col in enumerate(cols):
        if vendor in str(col).lower():
            index = i

    if index == -1:
        return -1
    temp = {k: v for k, v in vendors_list.iloc[:, [0, index]].values}
    mapping = {}
    for k, v in temp.items():
        if str(v).startswith('SiteDB'):
            if str(v) == 'SiteDB':
                v = k
            else:
                v = str(v).split('--')[1]
        mapping[k] = v

    return mapping


def calculate_bbh(opco):
    if opco == 'CG':
        df = pd.read_csv(config[opco]['raw'], low_memory=False, delimiter=';')

        cell = df['Segment Name'].tolist()
        bsc = df['BSC name'].tolist()
        condition = [(cell[i].lower(), bsc[i].lower()) for i in range(len(cell))]

        sitedb = pd.read_csv(config[opco]['sitedb'], low_memory=False)
        sitedb['cell'] = sitedb['CI-Name'].str.lower()
        sitedb['bsc'] = sitedb['BSC'].str.lower()
        sitedb_b = sitedb[sitedb[['cell', 'bsc']].apply(tuple, axis=1).isin(condition)]

        hourly = pd.merge(sitedb_b, df, how='inner', left_on=[
                          'CI-Name', 'BSC'], right_on=['Segment Name', 'BSC name'])
        hourly = hourly.sort_values(['PERIOD_START_TIME'])
        all_bbh = hourly.sort_values(by=['total_traffic_erlangs', 'PERIOD_START_TIME'],
                                     ascending=[False, True]).drop_duplicates('CI-Name').sort_index()
        all_bbh = all_bbh.rename(columns={'PERIOD_START_TIME': 'Period_start_time'})

    elif opco == 'CH':
        sitedb = pd.read_csv(config[opco]['sitedb'])

        h1 = pd.read_csv(config[opco]['huawei1'], low_memory=False)
        h1['cell_name'] = h1['Object Name'].str.split(
            ',', expand=True)[0].str.split('=', expand=True)[1]
        h2 = pd.read_csv(config[opco]['huawei2'], low_memory=False)
        h2['cell_name'] = h2['Object Name'].str.split(
            ',', expand=True)[0].str.split('=', expand=True)[1]
        h3 = pd.read_csv(config[opco]['huawei3'], low_memory=False)
        h3[['Object Name', 'TRX']] = h3['Object Name'].str.split('/TRX:', expand=True)
        h3['Object Name'] = h3['Object Name'].str.replace('/Cell:', '/GCELL:')
        h3 = h3[['Result Time', 'Granularity Period', 'Object Name', 'Reliability', 'AVG_RxQual_samples_0_4_Denom',
                 'AVG_RxQual_samples_0_4_Nom', 'SQI_Denom', 'SQI_Nom']].groupby(
            ['Result Time', 'Granularity Period', 'Object Name', 'Reliability']).sum().reset_index()
        h3['SQI'] = h3['SQI_Nom'] / h3['SQI_Denom']
        h3['AVG_RxQual_samples_0_4'] = h3['AVG_RxQual_samples_0_4_Nom'] / \
            h3['AVG_RxQual_samples_0_4_Denom']
        h3['cell_name'] = h3['Object Name'].str.split(
            ',', expand=True)[0].str.split('=', expand=True)[1]
        h4 = pd.read_csv(config[opco]['huawei4'], low_memory=False)
        h4['cell_name'] = h4['Object Name'].str.split(
            ',', expand=True)[0].str.split('=', expand=True)[1]

        cols = ['Result Time', 'cell_name']

        res1 = pd.merge(h1, h2, how='inner', on=cols)
        c1 = []
        for c in res1.columns:
            if c.endswith('_y'):
                continue
            c1.append(c)
        res1 = res1[c1]
        c2 = []
        for c in res1.columns:
            if c.endswith('_x'):
                c = c[:-2]
            c2.append(c)

        res1.columns = c2

        res1 = pd.merge(res1, h3, how='inner', on=cols)
        c1 = []
        for c in res1.columns:
            if c.endswith('_y'):
                continue
            c1.append(c)
        res1 = res1[c1]
        c2 = []
        for c in res1.columns:
            if c.endswith('_x'):
                c = c[:-2]
            c2.append(c)

        res1.columns = c2

        res1 = pd.merge(res1, h4, how='inner', on=cols)
        c1 = []
        for c in res1.columns:
            if c.endswith('_y'):
                continue
            c1.append(c)
        res1 = res1[c1]
        c2 = []
        for c in res1.columns:
            if c.endswith('_x'):
                c = c[:-2]
            c2.append(c)

        res1.columns = c2

        res1['BSC'] = res1['Object Name'].str.split('/', expand=True)[0]
        res1['Object Name'] = res1['Object Name'].str.split(
            ',', expand=True)[0].str.split('=', expand=True)[1]

        oname = res1['Object Name'].tolist()
        bsc = res1['BSC'].tolist()

        condition = [(oname[i].lower(), bsc[i].lower()) for i in range(len(oname))]

        sitedb['cell'] = sitedb['OSS_Cell_ID-Name'].str.lower()
        sitedb['bsc'] = sitedb['BSC'].str.lower()

        sitedb_h = sitedb[sitedb[['cell', 'bsc']].apply(tuple, axis=1).isin(condition)]
        sitedb_h = sitedb_h.drop(columns=['cell', 'bsc'])

        sitedb = sitedb.drop(columns=['cell', 'bsc'])

        res1 = pd.merge(res1, sitedb_h, how='inner', left_on=[
            'Object Name'], right_on=['OSS_Cell_ID-Name'])

        bsc = res1['BSC_x'].tolist()

        h_map = fetch_mapping('huawei', opco)

        for k, v in h_map.items():
            if type(v) == float:
                h_map[k] = k
                res1[k] = 0

        res1['SDCCH_Assignment_Success_Rate'] = res1['SDCCH Assignment Success Rate']

        h_map['Equipped_Erlang_Capacity_forVoice'] = 'Equipped_Erlang_Capacity_forVoice'

        res1 = res1[list(h_map.values())]
        res1.columns = list(h_map.keys())

        res1['EBSS_name'] = bsc

        e1 = pd.read_csv(config[opco]['ericsson1'], low_memory=False)
        e2 = pd.read_csv(config[opco]['ericsson2'], low_memory=False)

        res2 = pd.concat([e1, e2])

        sitedb_e = sitedb[sitedb['OSS_Cell_ID-Name'].isin(
            list(res2['SCE name'])) & sitedb['BSC'].isin(list(res2['EBSS name']))]

        res2 = pd.merge(res2, sitedb_e, how='inner', left_on=[
            'SCE name'], right_on=['OSS_Cell_ID-Name'])

        e_map = fetch_mapping('ericsson', opco)

        res2 = res2.rename(columns={
            'AVG_RxQual_samples_0_4': 'AVG_RxQual_samples__4',
            'AVG_RxQual_samples_0_4_Nom': 'AVG_RxQual_samples__4_Nom',
            'AVG_RxQual_samples_0_4_Denom': 'AVG_RxQual_samples__4_Denom'
        })

        for k, v in e_map.items():
            if type(v) == float or v not in list(res2.columns):
                e_map[k] = k
                res2[k] = 0

        e_map['Equipped_Erlang_Capacity_forVoice'] = 'Equipped_Erlang_Capacity_forVoice'

        res2 = res2[list(e_map.values())]
        res2.columns = list(e_map.keys())

        hourly_2g = pd.concat([res1, res2])

        hourly_2g['Period_start_time'] = pd.to_datetime(
            hourly_2g['Period_start_time']).dt.strftime('%d-%m-%Y %H:%M:%S')
        hourly_2g['Date'] = pd.to_datetime(hourly_2g['Date']).dt.strftime('%d-%m-%Y')
        hourly_2g['Hour'] = pd.to_datetime(hourly_2g['Hour']).dt.strftime('%H')

        # hourly_2g = hourly_2g.fillna(0)

        hourly_2g = hourly_2g.reset_index()

        temp1 = hourly_2g.copy()
        all_bbh = temp1.sort_values(by=['Total_Traffic_Erlangs', 'Hour'],
                                    ascending=[False, True]).drop_duplicates('E3GN_name').sort_index()
        all_bbh['Cell_Utilization'] = (all_bbh['Total_Traffic_Erlangs'] / all_bbh[
            'Equipped_Erlang_Capacity_forVoice']) * 100
        all_bbh['CSSR'] = np.NaN
        all_bbh = all_bbh.drop(columns=['index', 'Date', 'Equipped_Erlang_Capacity_forVoice'])
        all_bbh = all_bbh.rename(columns={'ESCE_name': 'CELL_ID', 'Hour': 'HOUR_ID'})

        site = pd.concat([sitedb_h, sitedb_e])
        all_bbh = pd.merge(all_bbh, site, how='left', left_on=[
                           'E3GN_name', 'EBSS_name'], right_on=['OSS_Cell_ID-Name', 'BSC'])

    return all_bbh


def update_report():
    for opco in config.keys():
        bbh = calculate_bbh(opco)
        report = pd.DataFrame()
        report['MO'] = bbh['OSS_Cell_ID-Name']
        report['Site ID'] = bbh['SITE_ID']
        report['MACRO/IBS'] = bbh['MACRO_IBS']
        report['BSC'] = bbh['BSC']
        report['Region'] = bbh['REGION']
        report['Showcase'] = bbh['SitePreference']

        if opco == 'CG':
            report['TCH Assign Succ Rate'] = bbh['TCH_Assig_Success_Rate_A']
            report['SDCCH Drop'] = bbh['sdcch_drop']
            report['SDCCH Cong'] = bbh['sdcch_blocking']
            report['TCH Cong'] = bbh['TCH_Blocking (User Perceived)']
            report['HOSUR'] = bbh['Handover_Success_Rate']
            report['CDR'] = bbh['TCH_Drop_New']
            report['TCH_SETUP_SUCC_RATE'] = bbh['TCH_setup_Succ_Rate_b']
        elif opco == 'CH':
            report['TCH Assign Succ Rate'] = bbh['TCH_Assig_Success_Rate']
            report['SDCCH Drop'] = bbh['SDCCH_Drop']
            report['SDCCH Cong'] = bbh['SDCCH_Blocking']
            report['TCH Cong'] = bbh['TCH_Blocking_User_Perceived']
            report['HOSUR'] = bbh['Handover_Success_Rate']
            report['CDR'] = bbh['TCH_Drop']
            report['TCH_SETUP_SUCC_RATE'] = bbh['TCH_Setup_Succ_Rate']

        wb = openpyxl.load_workbook(config[opco]['template'])
        bbh['Period_start_time'] = pd.to_datetime(
            bbh['Period_start_time']).dt.strftime('%m/%d/%Y %H:%M')
        date = (bbh['Period_start_time'].tolist()[0]).split()[0]

        std = ['MO', 'Site ID', 'MACRO/IBS', 'BSC', 'Region', 'Showcase']

        for ws in wb.worksheets:
            if ws.sheet_state == 'visible':
                sheet = str(ws).split('"')[1]
                if sheet in list(report.columns):
                    df = report[std + [sheet]]
                    c = 6
                    rowIndex = 1
                    colIndex = 1
                    while colIndex > 0:
                        if ws.cell(row=rowIndex, column=colIndex).value is None:
                            break
                        colIndex += 1

                    if colIndex == 52:
                        for i in range(rowIndex, ws.max_row + 1):
                            for j in range(7, colIndex):
                                ws.cell(row=i, column=j).value = ws.cell(row=i, column=j+1).value
                        colIndex -= 1

                    for i in range(rowIndex + 1, ws.max_row + 1):
                        cell = ws.cell(i, 1).value
                        if cell in list(df['MO']):
                            temp = df[df['MO'] == cell]
                            for j in range(2, c + 1):
                                ws.cell(row=i, column=j).value = temp[ws.cell(
                                    row=rowIndex, column=j).value].values[0]
                            ws.cell(row=i, column=colIndex).value = temp[sheet].values[0]
                    ws.cell(row=rowIndex, column=colIndex).value = date

        date = datetime.datetime.strptime(date, '%m/%d/%Y').strftime('%Y%m%d')
        wb.save(config[opco]['output'] + 'Network_Cell_list_' + opco + '_' + date + '.xlsx')
        wb.close()


update_report()
