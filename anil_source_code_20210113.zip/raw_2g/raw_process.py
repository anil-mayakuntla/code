import pandas as pd
import numpy as np
import os


def fetch_mapping(vendor):
    vendors_list = pd.read_excel('./input/2g/2G_Mapping_All_Vendors.xlsx')
    cols = []
    for col in vendors_list:
        if 'file name' in str(col).lower() or 'file_name' in str(col).lower():
            continue
        cols.append(col)

    vendors_list = vendors_list[cols]

    index = -1
    for i, col in enumerate(cols):
        if vendor in str(col).lower():
            index = i

    if index == -1:
        return -1
    temp = {k: v for k, v in vendors_list.iloc[:, [0, index]].values}
    mapping = {}
    for k, v in temp.items():
        if str(v).startswith('SiteDB'):
            if str(v) == 'SiteDB':
                v = k
            else:
                v = str(v).split('--')[1]
        mapping[k] = v

    return mapping


def process(folder):
    input_path = './input/2g/'

    sitedb = pd.read_csv(input_path + 'SiteDB_2G_CH_17-08-2020.csv')

    h1 = pd.read_csv(input_path + folder + '/Huawei/GDC_NPM_2G_Hourly_1.csv', low_memory=False)
    h1['cell_name'] = h1['Object Name'].str.split(',', expand=True)[0].str.split('=', expand=True)[1]
    h2 = pd.read_csv(input_path + folder + '/Huawei/GDC_NPM_2G_Hourly_2.csv', low_memory=False)
    h2['cell_name'] = h2['Object Name'].str.split(',', expand=True)[0].str.split('=', expand=True)[1]
    h3 = pd.read_csv(input_path + folder + '/Huawei/GDC_NPM_2G_Hourly_3.csv', low_memory=False)
    h3[['Object Name', 'TRX']] = h3['Object Name'].str.split('/TRX:', expand=True)
    h3['Object Name'] = h3['Object Name'].str.replace('/Cell:', '/GCELL:')
    h3 = h3[['Result Time', 'Granularity Period', 'Object Name', 'Reliability', 'AVG_RxQual_samples_0_4_Denom',
             'AVG_RxQual_samples_0_4_Nom', 'SQI_Denom', 'SQI_Nom']].groupby(
        ['Result Time', 'Granularity Period', 'Object Name', 'Reliability']).sum().reset_index()
    h3['SQI'] = h3['SQI_Nom'] / h3['SQI_Denom']
    h3['AVG_RxQual_samples_0_4'] = h3['AVG_RxQual_samples_0_4_Nom'] / h3['AVG_RxQual_samples_0_4_Denom']
    h3['cell_name'] = h3['Object Name'].str.split(',', expand=True)[0].str.split('=', expand=True)[1]
    h4 = pd.read_csv(input_path + folder + '/Huawei/GDC_NPM_2G_Hourly_4.csv', low_memory=False)
    h4['cell_name'] = h4['Object Name'].str.split(',', expand=True)[0].str.split('=', expand=True)[1]

    cols = ['Result Time', 'cell_name']

    res1 = pd.merge(h1, h2, how='inner', on=cols)
    c1 = []
    for c in res1.columns:
        if c.endswith('_y'):
            continue
        c1.append(c)
    res1 = res1[c1]
    c2 = []
    for c in res1.columns:
        if c.endswith('_x'):
            c = c[:-2]
        c2.append(c)

    res1.columns = c2

    res1 = pd.merge(res1, h3, how='inner', on=cols)
    c1 = []
    for c in res1.columns:
        if c.endswith('_y'):
            continue
        c1.append(c)
    res1 = res1[c1]
    c2 = []
    for c in res1.columns:
        if c.endswith('_x'):
            c = c[:-2]
        c2.append(c)

    res1.columns = c2

    res1 = pd.merge(res1, h4, how='inner', on=cols)
    c1 = []
    for c in res1.columns:
        if c.endswith('_y'):
            continue
        c1.append(c)
    res1 = res1[c1]
    c2 = []
    for c in res1.columns:
        if c.endswith('_x'):
            c = c[:-2]
        c2.append(c)

    res1.columns = c2

    res1['BSC'] = res1['Object Name'].str.split('/', expand=True)[0]
    res1['Object Name'] = res1['Object Name'].str.split(
        ',', expand=True)[0].str.split('=', expand=True)[1]

    oname = res1['Object Name'].tolist()
    bsc = res1['BSC'].tolist()

    condition = [(oname[i].lower(), bsc[i].lower()) for i in range(len(oname))]

    sitedb['cell'] = sitedb['OSS_Cell_ID-Name'].str.lower()
    sitedb['bsc'] = sitedb['BSC'].str.lower()

    sitedb_h = sitedb[sitedb[['cell', 'bsc']].apply(tuple, axis=1).isin(condition)]
    sitedb_h = sitedb_h.drop(columns=['cell', 'bsc'])

    res1 = pd.merge(res1, sitedb_h, how='inner', left_on=[
        'Object Name'], right_on=['OSS_Cell_ID-Name'])

    bsc = res1['BSC_x'].tolist()

    h_map = fetch_mapping('huawei')

    for k, v in h_map.items():
        if type(v) == float:
            h_map[k] = k
            res1[k] = 0

    res1['SDCCH_Assignment_Success_Rate'] = res1['SDCCH Assignment Success Rate']

    h_map['Equipped_Erlang_Capacity_forVoice'] = 'Equipped_Erlang_Capacity_forVoice'

    res1 = res1[list(h_map.values())]
    res1.columns = list(h_map.keys())

    res1['EBSS_name'] = bsc

    e1 = pd.read_csv(input_path + folder + '/2G_RAW_0020.csv', low_memory=False)
    e2 = pd.read_csv(input_path + folder + '/2G_RAW_2123.csv', low_memory=False)

    res2 = pd.concat([e1, e2])

    sitedb_e = sitedb[sitedb['OSS_Cell_ID-Name'].isin(
        list(res2['SCE name'])) & sitedb['BSC'].isin(list(res2['EBSS name']))]

    res2 = pd.merge(res2, sitedb_e, how='inner', left_on=[
        'SCE name'], right_on=['OSS_Cell_ID-Name'])

    e_map = fetch_mapping('ericsson')

    res2 = res2.rename(columns={
        'AVG_RxQual_samples_0_4': 'AVG_RxQual_samples__4',
        'AVG_RxQual_samples_0_4_Nom': 'AVG_RxQual_samples__4_Nom',
        'AVG_RxQual_samples_0_4_Denom': 'AVG_RxQual_samples__4_Denom'
    })

    for k, v in e_map.items():
        if type(v) == float or v not in list(res2.columns):
            e_map[k] = k
            res2[k] = 0

    e_map['Equipped_Erlang_Capacity_forVoice'] = 'Equipped_Erlang_Capacity_forVoice'

    res2 = res2[list(e_map.values())]
    res2.columns = list(e_map.keys())

    hourly_2g = pd.concat([res1, res2])

    hourly_2g['Period_start_time'] = pd.to_datetime(
        hourly_2g['Period_start_time']).dt.strftime('%d-%m-%Y %H:%M:%S')
    hourly_2g['Date'] = pd.to_datetime(hourly_2g['Date']).dt.strftime('%d-%m-%Y')
    hourly_2g['Hour'] = pd.to_datetime(hourly_2g['Hour']).dt.strftime('%H')

    hourly_2g['TCH_Assig_Success_Rate'] = (hourly_2g['TCH_Assig_Success_Rate_Nom'] / hourly_2g['TCH_Assig_Success_Rate_Denom']) * 100
    hourly_2g['TCH_Drop'] = (hourly_2g['TCH_Drop_Nom'] / hourly_2g['TCH_Drop_Nom_Denom']) * 100

    # hourly_2g = hourly_2g.fillna(0)
    hourly_2g['Traffic_AMR_Full_Rate_Erlangs'] = hourly_2g['Traffic_AMR_Full_Rate_Erlangs'].fillna(0)
    hourly_2g['Traffic_AMR_Half_Rate_Erlangs'] = hourly_2g['Traffic_AMR_Half_Rate_Erlangs'].fillna(0)

    hourly_2g = hourly_2g.reset_index()

    temp1 = hourly_2g.copy()
    all_bbh = temp1.sort_values(by=['Total_Traffic_Erlangs', 'Hour'], ascending=[False, True]).drop_duplicates('E3GN_name').sort_index()
    all_bbh['Cell_Utilization'] = (all_bbh['Total_Traffic_Erlangs'] / all_bbh['Equipped_Erlang_Capacity_forVoice']) * 100
    all_bbh['CSSR'] = np.NaN
    all_bbh = all_bbh.drop(columns=['index', 'Date', 'Equipped_Erlang_Capacity_forVoice'])
    all_bbh = all_bbh.rename(columns={'ESCE_name': 'CELL_ID', 'Hour': 'HOUR_ID'})

    temp1 = hourly_2g.copy()
    temp2 = temp1[['Total_Traffic_Erlangs', 'Hour']].groupby(['Hour']).sum().reset_index()
    hr = ((temp2.sort_values(['Total_Traffic_Erlangs'], ascending=False))['Hour'].tolist())[0]
    all_nbh = temp1[temp1['Hour'] == hr]
    # all_nbh = temp1.loc[
    #     temp1['Hour'] == (temp1[temp1['Total_Traffic_Erlangs'] == temp1['Total_Traffic_Erlangs'].max()])['Hour'].values[
    #         0]]
    all_nbh['CSSR'] = np.NaN
    all_nbh = all_nbh.drop(
        columns=['index', 'Hour', 'Date', 'SDCCH_TRAFFIC', 'SDCCH_Availability', 'SDCCH_Assignment_Success_Rate',
                 'HQ_TOWN', 'region', 'Equipped_Erlang_Capacity_forVoice'])

    temp1 = hourly_2g.copy()
    gprs_bbh = temp1.sort_values(by=['Tot_vol_data_downloaded', 'Hour'], ascending=[False, True]).drop_duplicates('E3GN_name').sort_index()
    gprs_bbh = gprs_bbh.drop(columns=['index', 'Equipped_Erlang_Capacity_forVoice'])

    temp1 = hourly_2g.copy()
    temp1 = temp1.drop(columns='index')
    std = ['Date', 'E3GN_name', 'EBSS_name', 'ESCE_name', 'C_SITE_PREFERENCE', 'C_VENDOR', 'Acceptance_Status',
           'region', 'HQ_TOWN', 'Equipped_Erlang_Capacity_forVoice']
    sum_list = ['Total_Traffic_Erlangs', 'Traffic_Full_Rate_Erlangs', 'Traffic_Half_Rate_Erlangs',
                'Random_Acc_Succ_Rate', 'Random_Acc_Succ_Rate_Nom', 'Random_Acc_Succ_Rate_Denom', 'SDCCH_Blocking',
                'SDCCH_Blocking_Nom', 'SDCCH_Blocking_Denom', 'SDCCH_Drop', 'SDCCH_Drop_Nom', 'SDCCH_Drop_Denom',
                'TCH_Blocking_User_Perceived', 'TCH_Blocking_Nom', 'TCH_Blocking_Denom', 'TCH_Assig_Success_Rate',
                'TCH_Assig_Success_Rate_Nom', 'TCH_Assig_Success_Rate_Denom', 'TCH_Drop', 'TCH_Drop_Nom',
                'TCH_Drop_Nom_Denom', 'Handover_Success_Rate', 'Handover_Success_Rate_Nom',
                'Handover_Success_Rate_Denom', 'TCH_Setup_Succ_Rate', 'TCH_Setup_Succ_Rate_Nom',
                'TCH_Setup_Succ_Rate_Denom', 'TCH_HO_Success_Rate', 'TCH_HO_Success_Rate_Nom',
                'TCH_HO_Success_Rate_Denom', 'Percentage_TBF_dropped', 'Percentage_TBF_drop_Nom',
                'Percentage_TBF_drop_Denom', 'Average_UL_throughput_per_TBF_GPRS', 'Avg_UL_thr_per_TBF_GPRS_Nom',
                'Avg_UL_thr_per_TBF_GPRS_Denom', 'Average_DL_throughput_per_TBF_GPRS', 'Avg_DL_thr_per_TBF_GPRS_Nom',
                'Avg_DL_thr_per_TBF_GPRS_Denom', 'Average_UL_throughput_per_TBF_EDGE', 'Avg_UL_thr_per_TBF_EDGE_Nom',
                'Avg_UL_thr_per_TBF_EDGE_Denom', 'Average_DL_throughput_per_TBF_EDGE', 'Avg_DL_thr_per_TBF_EDGE_Nom',
                'Avg_DL_thr_per_TBF_EDGE_Denom', 'Tot_vol_data_downloaded', 'Tot_Cell_Outage_Minutes_',
                'Soft_Blocking_Nom', 'Soft_Blocking_Denom', 'Hard_Blocking', 'Hard_Blocking_Nom', 'Hard_Blocking_Denom',
                'AVG_RxQual_samples_0_4', 'AVG_RxQual_samples_0_4_Nom', 'AVG_RxQual_samples_0_4_Denom', 'SQI_Nom',
                'SQI_Denom', 'Total_EDGE_Plus_GPRS', 'Total_EDGE_UL_data_download', 'Total_EDGE_DL_data_download',
                'Total_GPRS_UL_data_download', 'Total_GPRS_DL_data_download', 'CSSR_num', 'CSSR_denum', 'cssr_num1',
                'cssr_num2', 'cssr_num3', 'cssr_denum1', 'cssr_denum2', 'cssr_denum3']
    avg_list = ['TCH_Availability', 'Traffic_AMR_Full_Rate_Erlangs', 'Traffic_AMR_Half_Rate_Erlangs']

    sum_df = temp1[std + sum_list]
    sum_df = sum_df.groupby(std).sum().reset_index()

    avg_df = temp1[std + avg_list]
    avg_df = avg_df.groupby(std).mean().reset_index()

    sum_df.loc[sum_df['SQI_Denom'] == 0, 'SQI'] = 100
    sum_df.loc[sum_df['SQI_Denom'] != 0, 'SQI'] = (sum_df['SQI_Nom'] / sum_df['SQI_Denom']) * 100

    sum_df['Random_Acc_Succ_Rate'] = (sum_df['Random_Acc_Succ_Rate_Nom'] / sum_df['Random_Acc_Succ_Rate_Denom']) * 100
    sum_df['SDCCH_Drop'] = (sum_df['SDCCH_Drop_Nom'] / sum_df['SDCCH_Drop_Denom']) * 100
    sum_df['TCH_Blocking_User_Perceived'] = (sum_df['TCH_Blocking_Nom'] / sum_df['TCH_Blocking_Denom']) * 100
    sum_df['TCH_Assig_Success_Rate'] = (sum_df['TCH_Assig_Success_Rate_Nom'] / sum_df[
        'TCH_Assig_Success_Rate_Nom']) * 100
    sum_df['TCH_Drop'] = (sum_df['TCH_Drop_Nom'] / sum_df['TCH_Drop_Nom_Denom']) * 100
    sum_df['Handover_Success_Rate'] = (sum_df['Handover_Success_Rate_Nom'] / sum_df[
        'Handover_Success_Rate_Denom']) * 100
    sum_df['TCH_Setup_Succ_Rate'] = (sum_df['TCH_Setup_Succ_Rate_Nom'] / sum_df['TCH_Setup_Succ_Rate_Denom']) * 100
    sum_df['TCH_HO_Success_Rate'] = (sum_df['TCH_HO_Success_Rate_Nom'] / sum_df['TCH_HO_Success_Rate_Denom']) * 100
    sum_df['SDCCH_Blocking'] = (sum_df['SDCCH_Blocking_Nom'] / sum_df['SDCCH_Blocking_Denom']) * 100

    sum_df['Network_Availabilty'] = ((1400 - sum_df['Tot_Cell_Outage_Minutes_']) / 1400) * 100

    sum_df['Soft_Blocking'] = (sum_df['Soft_Blocking_Nom'] / sum_df['Soft_Blocking_Denom']) * 100
    sum_df.loc[sum_df['Soft_Blocking'] < 0, 'Soft_Blocking'] = 0

    all_daily = pd.merge(sum_df, avg_df, how='inner', on=std)

    all_daily = all_daily.rename(columns={'Date': 'Period_start_time'})

    cols = []
    for col in hourly_2g:
        if col in list(all_daily.columns):
            cols.append(col)

    all_daily = all_daily[cols]
    all_daily['CSSR'] = np.NaN
    all_daily = all_daily.rename(columns={'HQ_TOWN': 'CITYID'})

    all_daily = all_daily.drop(columns=['Equipped_Erlang_Capacity_forVoice'])

    if not os.path.isdir(input_path + folder + '/processed/'):
        os.mkdir(input_path + folder + '/processed/')

    hourly_2g = hourly_2g[list(hourly_2g.columns)[:-5]]
    if 'index' in list(hourly_2g.columns):
        hourly_2g = hourly_2g.drop(columns=['index'])
    if 'Equipped_Erlang_Capacity_forVoice' in list(hourly_2g.columns):
        hourly_2g = hourly_2g.drop(columns=['Equipped_Erlang_Capacity_forVoice'])
    if 'SDCCH_TRAFFIC' in list(hourly_2g.columns):
        hourly_2g = hourly_2g.drop(columns=['SDCCH_TRAFFIC'])

    hourly_2g.to_csv(input_path + folder + '/processed/network_2G_hourly_' + folder + '.csv', index=False)
    all_bbh.to_csv(input_path + folder + '/processed/network_all_bbh_kpi_' + folder + '.csv', index=False)
    all_nbh.to_csv(input_path + folder + '/processed/network_all_nbh_kpi_' + folder + '.csv', index=False)
    all_daily.to_csv(input_path + folder + '/processed/network_all_daily_kpi_' + folder + '.csv', index=False)
    gprs_bbh.to_csv(input_path + folder + '/processed/network_gprs_bbh_kpi_' + folder + '.csv', index=False)


process('20200817')
