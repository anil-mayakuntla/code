import pandas as pd
import openpyxl
import datetime
import json


config = json.load(open('./config.json'))


def adjust_sheet(sheet):
    colIndex = 3
    while sheet.cell(row=2, column=colIndex).value is not None:
        colIndex += 1

    if colIndex > 31:
        colIndex -= 1
        for i in range(3, 31):
            for j in range(2, 43):
                sheet.cell(row=j, column=i).value = sheet.cell(row=j, column=i + 1).value

    return colIndex


for opco in config.keys():
    hourly_2g = pd.read_csv(config[opco]['hourly_2g'])
    hourly_3g = pd.read_csv(config[opco]['hourly_3g'])

    report = openpyxl.load_workbook(config[opco]['template'])

    date = hourly_2g['date_start'][0]
    date = datetime.datetime.strftime(datetime.datetime.strptime(date, '%m-%d-%Y'), '%d %b')

    sheet1 = report['Daily_traffic ']

    colIndex = adjust_sheet(sheet1)

    daily_traffic1 = hourly_2g[['hour_id', 'tch_traffic_carried']
                               ].groupby('hour_id').sum().reset_index()

    df1 = {
        'hour_id': 'Overall',
        'tch_traffic_carried': daily_traffic1['tch_traffic_carried'].sum()
    }

    daily_traffic1 = daily_traffic1.append(df1, ignore_index=True)

    daily_traffic2 = hourly_2g[['showcase', 'tch_traffic_carried']
                               ].groupby('showcase').sum().reset_index()

    daily_traffic3 = hourly_2g[['sales_region', 'tch_traffic_carried']
                               ].groupby('sales_region').sum().reset_index()

    sheet1.cell(row=2, column=colIndex).value = date

    for i in range(3, 28):
        sheet1.cell(row=i, column=colIndex).value = daily_traffic1['tch_traffic_carried'][i-3]

    for i in range(29, 32):
        temp = daily_traffic2[daily_traffic2['showcase'] == sheet1.cell(row=i, column=2).value]
        temp = temp['tch_traffic_carried'].to_numpy().tolist()
        sheet1.cell(row=i, column=colIndex).value = temp[0]

    for i in range(34, 43):
        temp = daily_traffic3[daily_traffic3['sales_region'] == sheet1.cell(row=i, column=2).value]
        temp = temp['tch_traffic_carried'].to_numpy().tolist()
        sheet1.cell(row=i, column=colIndex).value = temp[0]

    sheet2 = report['CS-3G Erlang Traffic']

    colIndex = adjust_sheet(sheet2)

    erlang_3g1 = hourly_3g[['period_start_time', 'total_traffic_voice_cs_voice']].groupby(
        'period_start_time').sum().reset_index()
    df2 = {
        'period_start_time': 'Overall',
        'total_traffic_voice_cs_voice': erlang_3g1['total_traffic_voice_cs_voice'].sum()
    }
    erlang_3g1 = erlang_3g1.append(df2, ignore_index=True)

    erlang_3g2 = hourly_3g[['Sales_Regions', 'total_traffic_voice_cs_voice']
                           ].groupby('Sales_Regions').sum().reset_index()

    sheet2.cell(row=2, column=colIndex).value = date

    for i in range(3, 28):
        sheet2.cell(row=i, column=colIndex).value = erlang_3g1['total_traffic_voice_cs_voice'][i-3]

    for i in range(34, 43):
        temp = erlang_3g2[erlang_3g2['Sales_Regions'] == sheet2.cell(row=i, column=2).value]
        temp = temp['total_traffic_voice_cs_voice'].to_numpy().tolist()
        sheet2.cell(row=i, column=colIndex).value = temp[0]

    sheet2.cell(3, 2).value = datetime.time(0, 0, 0)

    sheet3 = report['Daily_traffic FR']

    colIndex = adjust_sheet(sheet3)

    fr1 = hourly_2g[['hour_id', 'fr_traffic']].groupby('hour_id').sum().reset_index()

    df3 = {
        'hour_id': 'Overall',
        'fr_traffic': fr1['fr_traffic'].sum()
    }

    fr1 = fr1.append(df3, ignore_index=True)

    fr2 = hourly_2g[['showcase', 'fr_traffic']].groupby('showcase').sum().reset_index()

    fr3 = hourly_2g[['sales_region', 'fr_traffic']].groupby('sales_region').sum().reset_index()

    sheet3.cell(row=2, column=colIndex).value = date

    for i in range(3, 28):
        sheet3.cell(row=i, column=colIndex).value = fr1['fr_traffic'][i-3]

    for i in range(29, 32):
        temp = fr2[fr2['showcase'] == sheet3.cell(row=i, column=2).value]
        temp = temp['fr_traffic'].to_numpy().tolist()
        sheet3.cell(row=i, column=colIndex).value = temp[0]

    for i in range(34, 43):
        temp = fr3[fr3['sales_region'] == sheet3.cell(row=i, column=2).value]
        temp = temp['fr_traffic'].to_numpy().tolist()
        sheet3.cell(row=i, column=colIndex).value = temp[0]

    sheet4 = report['Daily_traffic HR']

    colIndex = adjust_sheet(sheet4)

    hr1 = hourly_2g[['hour_id', 'hr_traffic']].groupby('hour_id').sum().reset_index()

    df4 = {
        'hour_id': 'Overall',
        'hr_traffic': hr1['hr_traffic'].sum()
    }

    hr1 = hr1.append(df4, ignore_index=True)

    hr2 = hourly_2g[['showcase', 'hr_traffic']].groupby('showcase').sum().reset_index()

    hr3 = hourly_2g[['sales_region', 'hr_traffic']].groupby('sales_region').sum().reset_index()

    sheet4.cell(row=2, column=colIndex).value = date

    for i in range(3, 28):
        sheet4.cell(row=i, column=colIndex).value = hr1['hr_traffic'][i-3]

    for i in range(29, 32):
        temp = hr2[hr2['showcase'] == sheet4.cell(row=i, column=2).value]
        temp = temp['hr_traffic'].to_numpy().tolist()
        sheet4.cell(row=i, column=colIndex).value = temp[0]

    for i in range(34, 43):
        temp = hr3[hr3['sales_region'] == sheet4.cell(row=i, column=2).value]
        temp = temp['hr_traffic'].to_numpy().tolist()
        sheet4.cell(row=i, column=colIndex).value = temp[0]

    date = datetime.datetime.strftime(datetime.datetime.strptime(
        hourly_2g['date_start'][0], '%m-%d-%Y'), '%Y%m%d')

    report.save(config[opco]['output'] + opco + '_Daily_Traffic_2G_3G_' + date + '.xlsx')
