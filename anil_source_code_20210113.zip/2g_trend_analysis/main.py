import pandas as pd
import openpyxl
import datetime
import json
import numpy as np


config = json.load(open('./config.json'))


def fetch_mapping(vendor):
    vendors_list = pd.read_excel('./input/2G_Mapping_All_Vendors.xlsx')
    cols = []
    for col in vendors_list:
        if 'file name' in str(col).lower() or 'file_name' in str(col).lower():
            continue
        cols.append(col)

    vendors_list = vendors_list[cols]

    index = -1
    for i, col in enumerate(cols):
        if vendor in str(col).lower():
            index = i

    if index == -1:
        return -1
    temp = {k: v for k, v in vendors_list.iloc[:, [0, index]].values}
    mapping = {}
    for k, v in temp.items():
        if str(v).startswith('SiteDB'):
            if str(v) == 'SiteDB':
                v = k
            else:
                v = str(v).split('--')[1]
        mapping[k] = v

    return mapping


def generate_process(opco):
    if opco == 'MG':
        df = pd.read_csv(config[opco]['raw'], low_memory=False, delimiter=';')

        cell = df['Segment Name'].tolist()
        bsc = df['BSC name'].tolist()
        condition = [(cell[i].lower(), bsc[i].lower()) for i in range(len(cell))]

        df['cell'] = df['Segment Name'].str.lower()
        df['bsc'] = df['BSC name'].str.lower()

        sitedb = pd.read_csv(config[opco]['sitedb'], low_memory=False)
        sitedb['cell'] = sitedb['CI-Name'].str.lower()
        sitedb['bsc'] = sitedb['BSC'].str.lower()
        sitedb_b = sitedb[sitedb[['cell', 'bsc']].apply(tuple, axis=1).isin(condition)]

        # hourly = pd.merge(sitedb_b, df, how='inner', left_on=[
        #                   'CI-Name', 'BSC'], right_on=['Segment Name', 'BSC name'])

        hourly = pd.merge(df, sitedb_b, how='inner', on=['cell', 'bsc'])

        n_map = fetch_mapping('nokia')

        for k, v in n_map.items():
            if type(v) == float:
                n_map[k] = k
                hourly[k] = 0

        hourly['SDCCH_Assignment_Success_Rate'] = hourly['SDCCH Assignment Success Rate']
        n_map['Equipped_Erlang_Capacity_forVoice'] = 'Equipped_Erlang_Capacity_forVoice'

        for k, v in n_map.items():
            if v == 'AVG_RxQual_samples__4':
                n_map[k] = 'AVG_RxQual_samples_0_4'
            if v == 'AVG_RxQual_samples__4_Nom':
                n_map[k] = 'AVG_RxQual_samples_0_4_Nom'
            if v == 'AVG_RxQual_samples__4_Denom':
                n_map[k] = 'AVG_RxQual_samples_0_4_Denom'
            if v == 'TCH_Drop_New':
                n_map[k] = 'TCH_DROP_NEW'
            if v == 'Handover_Success_Rate':
                n_map[k] = 'handover_success_rate'
            if v == 'Cell id':
                n_map[k] = 'OSS_Cell_ID-Name'

        n_map.pop('SDCCH_TRAFFIC')
        n_map.pop('SDCCH_Availability')

        hourly = hourly[list(n_map.values())]
        hourly.columns = list(n_map.keys())

        hourly['Period_start_time'] = pd.to_datetime(
            hourly['Period_start_time']).dt.strftime('%d-%m-%Y %H:%M:%S')
        hourly['Date'] = pd.to_datetime(hourly['Date']).dt.strftime('%d-%m-%Y')
        hourly['Hour'] = pd.to_datetime(hourly['Hour']).dt.strftime('%H')
        hourly['TCH_Assig_Success_Rate'] = (hourly['TCH_Assig_Success_Rate_Nom'] / hourly['TCH_Assig_Success_Rate_Denom']) * 100
        hourly['TCH_Drop'] = (hourly['TCH_Drop_Nom'] / hourly['TCH_Drop_Nom_Denom']) * 100

        # hourly = hourly.sort_values(by=['Hour'], ascending=True)

        # hourly = hourly.fillna(0)
        hourly['Traffic_AMR_Full_Rate_Erlangs'] = hourly['Traffic_AMR_Full_Rate_Erlangs'].fillna(0)
        hourly['Traffic_AMR_Half_Rate_Erlangs'] = hourly['Traffic_AMR_Half_Rate_Erlangs'].fillna(0)

        temp1 = hourly.copy()
        all_bbh = temp1.sort_values(by=['Total_Traffic_Erlangs', 'Hour'],
                                    ascending=[False, True]).drop_duplicates('E3GN_name').sort_index()
        all_bbh['CSSR'] = (all_bbh['CSSR_num'] / all_bbh['CSSR_denum']) * 100
        all_bbh['Cell_Utilization'] = (all_bbh['Total_Traffic_Erlangs'] / all_bbh[
            'Equipped_Erlang_Capacity_forVoice']) * 100
        all_bbh['cell'] = all_bbh['E3GN_name'].str.lower()
        all_bbh['bsc'] = all_bbh['EBSS_name'].str.lower()

        temp1 = hourly.copy()

        temp2 = temp1[['Total_Traffic_Erlangs', 'Hour']].groupby(['Hour']).sum().reset_index()
        hr = ((temp2.sort_values(['Total_Traffic_Erlangs'], ascending=False))['Hour'].tolist())[0]
        all_nbh = temp1[temp1['Hour'] == hr]
        # all_nbh = temp1.loc[temp1['Hour'] == (
        #     temp1[temp1['Total_Traffic_Erlangs'] == temp1['Total_Traffic_Erlangs'].max()])['Hour'].values[0]]
        all_nbh['cell'] = all_nbh['E3GN_name'].str.lower()
        all_nbh['bsc'] = all_nbh['EBSS_name'].str.lower()

        temp1 = hourly.copy()
        gprs_bbh = temp1.sort_values(by=['Tot_vol_data_downloaded', 'Hour'], ascending=[False, True]).drop_duplicates(
            'E3GN_name').sort_index()
        gprs_bbh['cell'] = gprs_bbh['E3GN_name'].str.lower()
        gprs_bbh['bsc'] = gprs_bbh['EBSS_name'].str.lower()

        temp1 = hourly.copy()
        std = ['Date', 'E3GN_name', 'EBSS_name', 'ESCE_name', 'C_SITE_PREFERENCE', 'C_VENDOR', 'Acceptance_Status',
               'region', 'HQ_TOWN', 'Equipped_Erlang_Capacity_forVoice']
        sum_list = ['Total_Traffic_Erlangs', 'Traffic_Full_Rate_Erlangs', 'Traffic_Half_Rate_Erlangs',
                    'Random_Acc_Succ_Rate', 'Random_Acc_Succ_Rate_Nom', 'Random_Acc_Succ_Rate_Denom', 'SDCCH_Blocking',
                    'SDCCH_Blocking_Nom', 'SDCCH_Blocking_Denom', 'SDCCH_Drop', 'SDCCH_Drop_Nom', 'SDCCH_Drop_Denom',
                    'TCH_Blocking_User_Perceived', 'TCH_Blocking_Nom', 'TCH_Blocking_Denom', 'TCH_Assig_Success_Rate',
                    'TCH_Assig_Success_Rate_Nom', 'TCH_Assig_Success_Rate_Denom', 'TCH_Drop', 'TCH_Drop_Nom',
                    'TCH_Drop_Nom_Denom', 'Handover_Success_Rate', 'Handover_Success_Rate_Nom',
                    'Handover_Success_Rate_Denom', 'TCH_Setup_Succ_Rate', 'TCH_Setup_Succ_Rate_Nom',
                    'TCH_Setup_Succ_Rate_Denom', 'TCH_HO_Success_Rate', 'TCH_HO_Success_Rate_Nom',
                    'TCH_HO_Success_Rate_Denom', 'Percentage_TBF_dropped', 'Percentage_TBF_drop_Nom',
                    'Percentage_TBF_drop_Denom', 'Average_UL_throughput_per_TBF_GPRS', 'Avg_UL_thr_per_TBF_GPRS_Nom',
                    'Avg_UL_thr_per_TBF_GPRS_Denom', 'Average_DL_throughput_per_TBF_GPRS',
                    'Avg_DL_thr_per_TBF_GPRS_Nom',
                    'Avg_DL_thr_per_TBF_GPRS_Denom', 'Average_UL_throughput_per_TBF_EDGE',
                    'Avg_UL_thr_per_TBF_EDGE_Nom',
                    'Avg_UL_thr_per_TBF_EDGE_Denom', 'Average_DL_throughput_per_TBF_EDGE',
                    'Avg_DL_thr_per_TBF_EDGE_Nom',
                    'Avg_DL_thr_per_TBF_EDGE_Denom', 'Tot_vol_data_downloaded', 'Tot_Cell_Outage_Minutes_',
                    'Soft_Blocking_Nom', 'Soft_Blocking_Denom', 'Hard_Blocking', 'Hard_Blocking_Nom',
                    'Hard_Blocking_Denom',
                    'AVG_RxQual_samples_0_4', 'AVG_RxQual_samples_0_4_Nom', 'AVG_RxQual_samples_0_4_Denom', 'SQI_Nom',
                    'SQI_Denom', 'Total_EDGE_Plus_GPRS', 'Total_EDGE_UL_data_download', 'Total_EDGE_DL_data_download',
                    'Total_GPRS_UL_data_download', 'Total_GPRS_DL_data_download', 'CSSR_num', 'CSSR_denum', 'cssr_num1',
                    'cssr_num2', 'cssr_num3', 'cssr_denum1', 'cssr_denum2', 'cssr_denum3']
        avg_list = ['TCH_Availability', 'Traffic_AMR_Full_Rate_Erlangs', 'Traffic_AMR_Half_Rate_Erlangs']

        sum_df = temp1[std + sum_list]
        sum_df = sum_df.groupby(std).aggregate(sum).reset_index()

        avg_df = temp1[std + avg_list]
        avg_df = avg_df.groupby(std).mean().reset_index()

        sum_df.loc[sum_df['SQI_Denom'] == 0, 'SQI'] = 100
        sum_df.loc[sum_df['SQI_Denom'] != 0, 'SQI'] = (
            sum_df['SQI_Nom'] / sum_df['SQI_Denom']) * 100

        sum_df['Random_Acc_Succ_Rate'] = (sum_df['Random_Acc_Succ_Rate_Nom'] / sum_df[
            'Random_Acc_Succ_Rate_Denom']) * 100
        sum_df['SDCCH_Drop'] = (sum_df['SDCCH_Drop_Nom'] / sum_df['SDCCH_Drop_Denom']) * 100
        sum_df['TCH_Blocking_User_Perceived'] = (
            sum_df['TCH_Blocking_Nom'] / sum_df['TCH_Blocking_Denom']) * 100
        sum_df['TCH_Assig_Success_Rate'] = (sum_df['TCH_Assig_Success_Rate_Nom'] / sum_df[
            'TCH_Assig_Success_Rate_Nom']) * 100
        sum_df['TCH_Drop'] = (sum_df['TCH_Drop_Nom'] / sum_df['TCH_Drop_Nom_Denom']) * 100
        sum_df['Handover_Success_Rate'] = (sum_df['Handover_Success_Rate_Nom'] / sum_df[
            'Handover_Success_Rate_Denom']) * 100
        sum_df['TCH_Setup_Succ_Rate'] = (
            sum_df['TCH_Setup_Succ_Rate_Nom'] / sum_df['TCH_Setup_Succ_Rate_Denom']) * 100
        sum_df['TCH_HO_Success_Rate'] = (
            sum_df['TCH_HO_Success_Rate_Nom'] / sum_df['TCH_HO_Success_Rate_Denom']) * 100
        sum_df['SDCCH_Blocking'] = (sum_df['SDCCH_Blocking_Nom'] / sum_df['SDCCH_Blocking_Denom'])*100

        sum_df['Network_Availabilty'] = ((1400 - sum_df['Tot_Cell_Outage_Minutes_']) / 1400) * 100

        sum_df['Soft_Blocking'] = (sum_df['Soft_Blocking_Nom'] /
                                   sum_df['Soft_Blocking_Denom']) * 100
        sum_df.loc[sum_df['Soft_Blocking'] < 0, 'Soft_Blocking'] = 0

        all_daily = pd.merge(sum_df, avg_df, how='inner', on=std)

        all_daily = all_daily.rename(columns={'Date': 'Period_start_time'})

        cols = []
        for col in hourly.columns:
            if col in list(all_daily.columns):
                cols.append(col)

        all_daily = all_daily[cols]
        all_daily['CSSR'] = np.NaN
        all_daily = all_daily.rename(columns={'HQ_TOWN': 'CITYID'})

        all_daily = all_daily.drop(columns=['Equipped_Erlang_Capacity_forVoice'])

        all_daily['cell'] = all_daily['E3GN_name'].str.lower()
        all_daily['bsc'] = all_daily['EBSS_name'].str.lower()

        if 'index' in list(hourly.columns):
            hourly = hourly.drop(columns=['index'])
        if 'Equipped_Erlang_Capacity_forVoice' in list(hourly.columns):
            hourly_2g = hourly.drop(columns=['Equipped_Erlang_Capacity_forVoice'])
        if 'SDCCH_TRAFFIC' in list(hourly.columns):
            hourly = hourly_2g.drop(columns=['SDCCH_TRAFFIC'])

        all_bbh = pd.merge(all_bbh, sitedb, how='left', on=['cell', 'bsc'])
        all_nbh = pd.merge(all_nbh, sitedb, how='left', on=['cell', 'bsc'])
        gprs_bbh = pd.merge(gprs_bbh, sitedb, how='left', on=['cell', 'bsc'])
        all_daily = pd.merge(all_daily, sitedb, how='left', on=['cell', 'bsc'])

        cols = []
        for col in all_bbh.columns:
            if col.endswith('_x'):
                temp = col[:-2]
                if temp not in cols:
                    col = temp
            cols.append(col)
        all_bbh.columns = cols

        cols = []
        for col in all_nbh.columns:
            if col.endswith('_x'):
                temp = col[:-2]
                if temp not in cols:
                    col = temp
            cols.append(col)
        all_nbh.columns = cols

        cols = []
        for col in gprs_bbh.columns:
            if col.endswith('_x'):
                temp = col[:-2]
                if temp not in cols:
                    col = temp
            cols.append(col)
        gprs_bbh.columns = cols

        cols = []
        for col in all_daily.columns:
            if col.endswith('_x'):
                temp = col[:-2]
                if temp not in cols:
                    col = temp
            cols.append(col)
        all_daily.columns = cols

        process_files = {
            'bbh': all_bbh,
            'nbh': all_nbh,
            'gprs': gprs_bbh,
            'daily': all_daily,
            'hourly': hourly,
        }

        for k, v in process_files.items():
            v.to_csv('./output/{0}.csv'.format(k), index=False)

        return process_files


def update_report():
    for opco in config.keys():
        process_files = generate_process(opco)

        all_nbh = process_files['nbh']
        date = (all_nbh['Date'].tolist())[0]
        date = datetime.datetime.strftime(datetime.datetime.strptime(date, '%d-%m-%Y'), '%d-%b-%Y')

        df1 = pd.DataFrame()
        df1['Cell Classification'] = all_nbh['SitePreference']
        df1['Vendor'] = all_nbh['Vendor']
        df1['Bsc'] = all_nbh['BSC']
        df1['Cell Name'] = all_nbh['CI-Name']
        df1['Cell Code'] = all_nbh['Site_Name']
        df1['Cell id'] = all_nbh['OSS_Cell_ID-Name']
        df1['Region'] = all_nbh['REGION']
        df1['Coveragetype'] = all_nbh['HQ_TOWN_y']
        df1['- (NBH Erl)'] = all_nbh['Total_Traffic_Erlangs']
        df1['- (SDCCH Blk rate)'] = all_nbh['SDCCH_Blocking']
        df1['- (SDCCH Drop rate)'] = all_nbh['SDCCH_Drop']
        df1['- (Soft Blocking)'] = all_nbh['Soft_Blocking']
        df1['- (TAR)'] = all_nbh['TCH_Assig_Success_Rate']
        df1['- (TBF Drope Rate)'] = all_nbh['Percentage_TBF_dropped']
        df1['- (TCH Blk rate)'] = all_nbh['TCH_Blocking_User_Perceived']
        df1['- (TCH Drop rate)'] = all_nbh['TCH_Drop']

        all_bbh = process_files['bbh']
        df2 = pd.DataFrame()
        df2['Cell Classification'] = all_bbh['SitePreference']
        df2['Vendor'] = all_bbh['Vendor']
        df2['Bsc'] = all_bbh['BSC']
        df2['Cell Name'] = all_bbh['CI-Name']
        df2['Cell Code'] = all_bbh['Site_Name']
        df2['Cell id'] = all_bbh['OSS_Cell_ID-Name']
        df2['Region'] = all_bbh['REGION']
        df2['Coveragetype'] = all_bbh['HQ_TOWN_y']
        df2['- (BBH Erl)'] = all_bbh['Total_Traffic_Erlangs']
        df2['- (BBH Erl FR)'] = all_bbh['Traffic_Full_Rate_Erlangs']
        df2['- (BBH Erl HR)'] = all_bbh['Traffic_Half_Rate_Erlangs']
        df2['- (BBHRASR)'] = all_bbh['Random_Acc_Succ_Rate']
        df2['- (CSSR)'] = all_bbh['CSSR']
        df2['- (TCH Utilization)'] = all_bbh['Cell_Utilization']

        all_gprs = process_files['gprs']
        df3 = pd.DataFrame()
        df3['Cell Classification'] = all_gprs['SitePreference']
        df3['Vendor'] = all_gprs['Vendor']
        df3['Bsc'] = all_gprs['BSC']
        df3['Cell Name'] = all_gprs['CI-Name']
        df3['Cell Code'] = all_gprs['Site_Name']
        df3['Cell id'] = all_gprs['OSS_Cell_ID-Name']
        df3['Region'] = all_gprs['REGION']
        df3['Coveragetype'] = all_gprs['HQ_TOWN_y']
        df3['- (EDGE DL Per TBF(Kbps))'] = all_gprs['Average_DL_throughput_per_TBF_EDGE']
        df3['- (EDGE UL Per TBF(Kbps))'] = all_gprs['Average_UL_throughput_per_TBF_EDGE']
        df3['- (GPRS DL Per TBF(Kbps))'] = all_gprs['Average_DL_throughput_per_TBF_GPRS']
        df3['- (GPRS UL Per TBF(Kbps))'] = all_gprs['Average_UL_throughput_per_TBF_GPRS']
        df3['- (Hard Blocking)'] = all_gprs['Hard_Blocking']
        df3['- (TOTAL_Vol_Traffic BH(Mbytes)'] = all_gprs['Tot_vol_data_downloaded']

        all_daily = process_files['daily']
        df4 = pd.DataFrame()
        df4['Cell Classification'] = all_daily['SitePreference']
        df4['Vendor'] = all_daily['Vendor']
        df4['Bsc'] = all_daily['BSC']
        df4['Cell Name'] = all_daily['CI-Name']
        df4['Cell Code'] = all_daily['Site_Name']
        df4['Cell id'] = all_daily['OSS_Cell_ID-Name']
        df4['Region'] = all_daily['REGION']
        df4['Coveragetype'] = all_daily['HQ_TOWN']
        df4['- (Daily HO Suc rate)'] = all_daily['Handover_Success_Rate']
        df4['- (Daily TCH Block)'] = all_daily['TCH_Blocking_User_Perceived']
        df4['- (HO Success rate)'] = all_daily['Handover_Success_Rate']
        df4['- (TCH FR AMR)'] = all_daily['Traffic_AMR_Full_Rate_Erlangs']
        df4['- (TCH HR AMR)'] = all_daily['Traffic_AMR_Half_Rate_Erlangs']
        df4['- (TOTAL_Vol_Traffic D(Mbytes))'] = all_daily['Tot_vol_data_downloaded']
        df4['- (Daily Erl)'] = all_daily['Total_Traffic_Erlangs']
        df4['- (Daily HO Att)'] = all_daily['Handover_Success_Rate_Denom']
        df4['- (Daily HO Suc)'] = all_daily['Handover_Success_Rate_Nom']
        df4['- (Daily SDCCH Att)'] = all_daily['SDCCH_Blocking_Denom']
        df4['- (Daily SDCCH Suc)'] = all_daily['SDCCH_Blocking_Nom']
        df4['- (Daily TCH Att)'] = all_daily['TCH_Drop_Nom_Denom']
        df4['- (Daily TCH Suc)'] = all_daily['TCH_Drop_Nom']
        df4['- (Daily TCH Drop)'] = all_daily['TCH_Drop']
        df4['- (Daily SDCCH Block)'] = all_daily['SDCCH_Blocking']
        df4['- (Daily SDCCH Drop)'] = all_daily['SDCCH_Drop']

        std = ['Cell Classification', 'Vendor', 'Bsc', 'Cell Name',
               'Cell Code', 'Cell id', 'Region', 'Coveragetype']

        res = pd.merge(df1, (pd.merge(df2, pd.merge(df3, df4, how='inner', on=std),
                                      how='inner', on=std)), how='inner', on=std)

        report = openpyxl.load_workbook(config[opco]['report'])

        for ws in report.worksheets:
            sheet = str(ws).split('"')[1]
            print(sheet)
            if sheet in list(res.columns):
                print('yes')
                row_max = 1
                while ws.cell(row=row_max, column=6).value is not None:
                    row_max += 1

                col_max = 1
                while ws.cell(row=1, column=col_max).value is not None:
                    col_max += 1

                if (col_max - len(std) - 1) >= 45:
                    for i in range(1, row_max):
                        for j in range(9, col_max):
                            ws.cell(row=i, column=j).value = ws.cell(row=i, column=j+1).value
                    col_max -= 1

                df = res[std+[sheet]]
                print('dumping data')
                ws.cell(row=1, column=col_max).value = date
                for i in range(2, row_max):
                    cell = ws.cell(row=i, column=6).value
                    if cell in list(df['Cell id']):
                        temp = df[df['Cell id'] == cell]
                        temp_data = temp.to_numpy().tolist()
                        for j in range(1, 9):
                            ws.cell(row=i, column=j).value = temp_data[0][j-1]
                        ws.cell(row=i, column=col_max).value = temp_data[0][-1]
                print('next sheet')
        date = datetime.datetime.strftime(datetime.datetime.strptime(date, '%d-%b-%Y'), '%Y%m%d')

        report.save(config[opco]['output'] + opco.upper() + '_2G_Trend_Analysis_' + str(date) + '.xlsx')


# generate_process('MG')
update_report()
