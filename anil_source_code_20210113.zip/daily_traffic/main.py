import pandas as pd
import datetime
import openpyxl
import json


hourly_2g_7 = pd.read_csv('./input/network_all_hourly_kpi_20200817.csv')
hourly_2g_1 = pd.read_csv('./input/network_all_hourly_kpi_20200817.csv')

hourly_3g_7 = pd.read_csv('./input/network_all_3g_kpi_nbh_24hrs_n_20200817.csv')
hourly_3g_1 = pd.read_csv('./input/network_all_3g_kpi_nbh_24hrs_n_20200817.csv')

hourly_4g_7 = pd.read_csv('./input/lte_mapa_kpis_report_Hourly_20200817.csv')
hourly_4g_1 = pd.read_csv('./input/lte_mapa_kpis_report_Hourly_20200817.csv')

gsm_ctrl_7 = hourly_2g_7[hourly_2g_7['region'].str.lower() == 'central'][['hour_id', 'tch_traffic_carried']].groupby(['hour_id']).sum().reset_index()
gsm_east_7 = hourly_2g_7[hourly_2g_7['region'].str.lower() == 'east'][['hour_id', 'tch_traffic_carried']].groupby(['hour_id']).sum().reset_index()
gsm_west_7 = hourly_2g_7[hourly_2g_7['region'].str.lower() == 'west'][['hour_id', 'tch_traffic_carried']].groupby(['hour_id']).sum().reset_index()
gsm_north_7 = hourly_2g_7[hourly_2g_7['region'].str.lower() == 'north'][['hour_id', 'tch_traffic_carried']].groupby(['hour_id']).sum().reset_index()
date_7 = datetime.datetime.strftime(datetime.datetime.strptime(hourly_2g_7['date_start'][0], '%m-%d-%Y'), '%d-%b')

gsm_ctrl_1 = hourly_2g_1[hourly_2g_1['region'].str.lower() == 'central'][['hour_id', 'tch_traffic_carried']].groupby(['hour_id']).sum().reset_index()
gsm_east_1 = hourly_2g_1[hourly_2g_1['region'].str.lower() == 'east'][['hour_id', 'tch_traffic_carried']].groupby(['hour_id']).sum().reset_index()
gsm_west_1 = hourly_2g_1[hourly_2g_1['region'].str.lower() == 'west'][['hour_id', 'tch_traffic_carried']].groupby(['hour_id']).sum().reset_index()
gsm_north_1 = hourly_2g_1[hourly_2g_1['region'].str.lower() == 'north'][['hour_id', 'tch_traffic_carried']].groupby(['hour_id']).sum().reset_index()
date_1 = datetime.datetime.strftime(datetime.datetime.strptime(hourly_2g_1['date_start'][0], '%m-%d-%Y'), '%d-%b')

gsm_data = [gsm_ctrl_7['tch_traffic_carried'].tolist(), gsm_ctrl_1['tch_traffic_carried'].tolist(),
            gsm_east_7['tch_traffic_carried'].tolist(), gsm_east_1['tch_traffic_carried'].tolist(),
            gsm_west_7['tch_traffic_carried'].tolist(), gsm_west_1['tch_traffic_carried'].tolist(),
            gsm_north_7['tch_traffic_carried'].tolist(), gsm_north_1['tch_traffic_carried'].tolist()]

dates = [date_7, date_1] * 4

data = []

for j in range(len(gsm_data[1])):
    l1 = []
    for i in range(len(gsm_data)):
        l1.append(gsm_data[i][j])
    data.append(l1)

data.insert(0, dates)

data.append(['']*len(data[1]))

wcdma_voice_ctrl_7 = hourly_3g_7[hourly_3g_7['REGION'].str.lower() == 'central'][['period_start_time', 'total_traffic_voice_cs_voice']].groupby(['period_start_time']).sum().reset_index()
wcdma_voice_east_7 = hourly_3g_7[hourly_3g_7['REGION'].str.lower() == 'east'][['period_start_time', 'total_traffic_voice_cs_voice']].groupby(['period_start_time']).sum().reset_index()
wcdma_voice_west_7 = hourly_3g_7[hourly_3g_7['REGION'].str.lower() == 'west'][['period_start_time', 'total_traffic_voice_cs_voice']].groupby(['period_start_time']).sum().reset_index()
wcdma_voice_north_7 = hourly_3g_7[hourly_3g_7['REGION'].str.lower() == 'north'][['period_start_time', 'total_traffic_voice_cs_voice']].groupby(['period_start_time']).sum().reset_index()

wcdma_voice_ctrl_1 = hourly_3g_1[hourly_3g_1['REGION'].str.lower() == 'central'][['period_start_time', 'total_traffic_voice_cs_voice']].groupby(['period_start_time']).sum().reset_index()
wcdma_voice_east_1 = hourly_3g_1[hourly_3g_1['REGION'].str.lower() == 'east'][['period_start_time', 'total_traffic_voice_cs_voice']].groupby(['period_start_time']).sum().reset_index()
wcdma_voice_west_1 = hourly_3g_1[hourly_3g_1['REGION'].str.lower() == 'west'][['period_start_time', 'total_traffic_voice_cs_voice']].groupby(['period_start_time']).sum().reset_index()
wcdma_voice_north_1 = hourly_3g_1[hourly_3g_1['REGION'].str.lower() == 'north'][['period_start_time', 'total_traffic_voice_cs_voice']].groupby(['period_start_time']).sum().reset_index()

wcdma_data_v = [wcdma_voice_ctrl_7['total_traffic_voice_cs_voice'], wcdma_voice_ctrl_1['total_traffic_voice_cs_voice'],
                wcdma_voice_east_7['total_traffic_voice_cs_voice'], wcdma_voice_east_1['total_traffic_voice_cs_voice'],
                wcdma_voice_west_7['total_traffic_voice_cs_voice'], wcdma_voice_west_1['total_traffic_voice_cs_voice'],
                wcdma_voice_north_7['total_traffic_voice_cs_voice'],
                wcdma_voice_north_1['total_traffic_voice_cs_voice']]

for j in range(len(wcdma_data_v[1])):
    l1 = []
    for i in range(len(wcdma_data_v)):
        l1.append(wcdma_data_v[i][j])
    data.append(l1)

data.append(['']*len(data[1]))

wcdma_data_ctrl_7 = hourly_3g_7[hourly_3g_7['REGION'].str.lower() == 'central'][['period_start_time', 'radio_network_load_ps_total']].groupby(['period_start_time']).sum().reset_index()
wcdma_data_east_7 = hourly_3g_7[hourly_3g_7['REGION'].str.lower() == 'east'][['period_start_time', 'radio_network_load_ps_total']].groupby(['period_start_time']).sum().reset_index()
wcdma_data_west_7 = hourly_3g_7[hourly_3g_7['REGION'].str.lower() == 'west'][['period_start_time', 'radio_network_load_ps_total']].groupby(['period_start_time']).sum().reset_index()
wcdma_data_north_7 = hourly_3g_7[hourly_3g_7['REGION'].str.lower() == 'north'][['period_start_time', 'radio_network_load_ps_total']].groupby(['period_start_time']).sum().reset_index()

wcdma_data_ctrl_1 = hourly_3g_1[hourly_3g_1['REGION'].str.lower() == 'central'][['period_start_time', 'radio_network_load_ps_total']].groupby(['period_start_time']).sum().reset_index()
wcdma_data_east_1 = hourly_3g_1[hourly_3g_1['REGION'].str.lower() == 'east'][['period_start_time', 'radio_network_load_ps_total']].groupby(['period_start_time']).sum().reset_index()
wcdma_data_west_1 = hourly_3g_1[hourly_3g_1['REGION'].str.lower() == 'west'][['period_start_time', 'radio_network_load_ps_total']].groupby(['period_start_time']).sum().reset_index()
wcdma_data_north_1 = hourly_3g_1[hourly_3g_1['REGION'].str.lower() == 'north'][['period_start_time', 'radio_network_load_ps_total']].groupby(['period_start_time']).sum().reset_index()

wcdma_data_d = [wcdma_data_ctrl_7['radio_network_load_ps_total'], wcdma_data_ctrl_1['radio_network_load_ps_total'],
                wcdma_data_east_7['radio_network_load_ps_total'], wcdma_data_east_1['radio_network_load_ps_total'],
                wcdma_data_west_7['radio_network_load_ps_total'], wcdma_data_west_1['radio_network_load_ps_total'],
                wcdma_data_north_7['radio_network_load_ps_total'],
                wcdma_data_north_1['radio_network_load_ps_total']]

for j in range(len(wcdma_data_d[1])):
    l1 = []
    for i in range(len(wcdma_data_d)):
        l1.append(wcdma_data_d[i][j])
    data.append(l1)

data.append(['']*len(data[1]))

data_2g_ctrl_7 = hourly_2g_7[hourly_2g_7['region'].str.lower() == 'central'][['hour_id', 'total_data_vol']].groupby(['hour_id']).sum().reset_index()
data_2g_east_7 = hourly_2g_7[hourly_2g_7['region'].str.lower() == 'east'][['hour_id', 'total_data_vol']].groupby(['hour_id']).sum().reset_index()
data_2g_west_7 = hourly_2g_7[hourly_2g_7['region'].str.lower() == 'west'][['hour_id', 'total_data_vol']].groupby(['hour_id']).sum().reset_index()
data_2g_north_7 = hourly_2g_7[hourly_2g_7['region'].str.lower() == 'north'][['hour_id', 'total_data_vol']].groupby(['hour_id']).sum().reset_index()

data_2g_ctrl_1 = hourly_2g_1[hourly_2g_1['region'].str.lower() == 'central'][['hour_id', 'total_data_vol']].groupby(['hour_id']).sum().reset_index()
data_2g_east_1 = hourly_2g_1[hourly_2g_1['region'].str.lower() == 'east'][['hour_id', 'total_data_vol']].groupby(['hour_id']).sum().reset_index()
data_2g_west_1 = hourly_2g_1[hourly_2g_1['region'].str.lower() == 'west'][['hour_id', 'total_data_vol']].groupby(['hour_id']).sum().reset_index()
data_2g_north_1 = hourly_2g_1[hourly_2g_1['region'].str.lower() == 'north'][['hour_id', 'total_data_vol']].groupby(['hour_id']).sum().reset_index()

data_2g_data = [data_2g_ctrl_7['total_data_vol'].tolist(), data_2g_ctrl_1['total_data_vol'].tolist(),
                data_2g_east_7['total_data_vol'].tolist(), data_2g_east_1['total_data_vol'].tolist(),
                data_2g_west_7['total_data_vol'].tolist(), data_2g_west_1['total_data_vol'].tolist(),
                data_2g_north_7['total_data_vol'].tolist(), data_2g_north_1['total_data_vol'].tolist()]

for j in range(len(data_2g_data[1])):
    l1 = []
    for i in range(len(data_2g_data)):
        l1.append(data_2g_data[i][j])
    data.append(l1)

data.append(['']*len(data[1]))

lte_data_ctrl_7 = hourly_4g_7[hourly_4g_7['region'].str.lower() == 'central'][['DATE_ID', '29_Total_24_HrsTraffic']].groupby(['DATE_ID']).sum().reset_index()
lte_data_east_7 = hourly_4g_7[hourly_4g_7['region'].str.lower() == 'east'][['DATE_ID', '29_Total_24_HrsTraffic']].groupby(['DATE_ID']).sum().reset_index()
lte_data_west_7 = hourly_4g_7[hourly_4g_7['region'].str.lower() == 'west'][['DATE_ID', '29_Total_24_HrsTraffic']].groupby(['DATE_ID']).sum().reset_index()
lte_data_north_7 = hourly_4g_7[hourly_4g_7['region'].str.lower() == 'north'][['DATE_ID', '29_Total_24_HrsTraffic']].groupby(['DATE_ID']).sum().reset_index()

lte_data_ctrl_1 = hourly_4g_1[hourly_4g_1['region'].str.lower() == 'central'][['DATE_ID', '29_Total_24_HrsTraffic']].groupby(['DATE_ID']).sum().reset_index()
lte_data_east_1 = hourly_4g_1[hourly_4g_1['region'].str.lower() == 'east'][['DATE_ID', '29_Total_24_HrsTraffic']].groupby(['DATE_ID']).sum().reset_index()
lte_data_west_1 = hourly_4g_1[hourly_4g_1['region'].str.lower() == 'west'][['DATE_ID', '29_Total_24_HrsTraffic']].groupby(['DATE_ID']).sum().reset_index()
lte_data_north_1 = hourly_4g_1[hourly_4g_1['region'].str.lower() == 'north'][['DATE_ID', '29_Total_24_HrsTraffic']].groupby(['DATE_ID']).sum().reset_index()

lte_data = [lte_data_ctrl_7['29_Total_24_HrsTraffic'], lte_data_ctrl_1['29_Total_24_HrsTraffic'],
            lte_data_east_7['29_Total_24_HrsTraffic'], lte_data_east_1['29_Total_24_HrsTraffic'],
            lte_data_west_7['29_Total_24_HrsTraffic'], lte_data_west_1['29_Total_24_HrsTraffic'],
            lte_data_north_7['29_Total_24_HrsTraffic'], lte_data_north_1['29_Total_24_HrsTraffic']]

for j in range(len(lte_data[1])):
    l1 = []
    for i in range(len(lte_data)):
        l1.append(lte_data[i][j])
    data.append(l1)

for i in range(len(data)):
    l1 = []
    for j in range(len(data[i])):
        l1.append(data[i][j])

# place the data in the excel
report = openpyxl.load_workbook('./input/Daily_traffic_report_20200817.xlsx')
sheet = report['Hourly Trend']

sheet.cell(row=8, column=3).value = data[0][0]
sheet.cell(row=8, column=4).value = data[0][1]

for i in range(len(data)):
    for j in range(len(data[i])):
        sheet.cell(row=i+8, column=j+5).value = data[i][j]

report.save('./output/Daily_traffic_report_20200817_1.xlsx')
report.close()
